﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Pawnshop
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            txtBoxLogin.Clear();
            passBoxPassword.Clear();
        }


        private void btnAuthorization_Click(object sender, RoutedEventArgs e)
        {
            Model.PawnshopEntities db = new Model.PawnshopEntities();

            if(txtBoxLogin.Text == "" || passBoxPassword.Password == "")
            {
                MessageBox.Show("Одно или несколько полей не заполнено");
            }

            else
            {
                Model.Employees employees = db.Employees.Where(x => x.Login == txtBoxLogin.Text && x.Password == passBoxPassword.Password).FirstOrDefault();
                if(employees != null)
                {
                    MessageBox.Show("Успешная авторизация");
                }
                else
                {
                    MessageBox.Show("Неверно введён логин или пароль");

                }
            }
        }
    }
}
